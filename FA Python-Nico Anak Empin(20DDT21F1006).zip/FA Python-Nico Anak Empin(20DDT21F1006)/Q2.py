import tkinter as tk
from tkinter import ttk

def combine():
    name1=ent1.get()
    name2=ent2.get()
    gmail=(name1+name2+"@gmail.com")
    lbl4.config(text=gmail)

def clear():
    ent1.config(text=clear)
    ent2.config(text=clear)
    lbl4.config(text="")

nico = tk.Tk()
nico.title("Automatic Username")
nico.geometry("350x200")

frame = ttk.LabelFrame(nico,text="Username Suggestion")
frame.place(x=25,y=10 ,width=300,height=150)

lbl1 = ttk.Label(frame, text="First Name :")
lbl1.place(x=20,y=10)
ent1 = ttk.Entry(frame)
ent1.place(x=110,y=10)

lbl2 = ttk.Label(frame, text="Second Name :")
lbl2.place(x=20,y=35)
ent2 = ttk.Entry(frame)
ent2.place(x=110,y=35)

lbl3 = ttk.Label(frame, text="Suggested :")
lbl3.place(x=20,y=60)
lbl4 = ttk.Label(frame)
lbl4.place(x=110,y=60)

btn1 = tk.Button(frame, text="Combine" ,command=combine)
btn1.place(x=110,y=85)

btn2 = tk.Button(frame, text="Clear",command=clear)
btn2.place(x=180,y=85)

btn3 = tk.Button(nico, text="Exit",command=exit)
btn3.place(x=270,y=170)

nico.mainloop()