class PasswordManager:
    def __init__(self,password,enter_password):
        self.password=password
        self.enter_password=enter_password

    def get_password(self):
        word =list[-1]
        return word

    def set_password(self):
        print("Your password is wrong")
        new_pass=input("Please enter your new password to reset : ")
        nico = open("password.txt","a")
        nico.write(new_pass+"\n")
        print("Password have successfully reset")

    def is_correct(self):
        if self.enter_password==obj.get_password():
            print("You have succesfully logged in")
        else:
            obj.set_password()

nico=open("password.txt").read()
list=nico.split()
word=input("Please enter your password : ")
obj=PasswordManager(list,word)
obj.is_correct()